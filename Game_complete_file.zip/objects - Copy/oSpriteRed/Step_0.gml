x_speed = 0 

y_speed = 0 


if (keyboard_check(vk_right)) { // if the d key is pressed 

    x_speed = movement_speed // add the movement speed to the x_speed variable 

} 

if (keyboard_check(vk_left)) { 

    x_speed = -movement_speed 

} 


if (keyboard_check(vk_up)) { 

    y_speed = -movement_speed 

} 


if (keyboard_check(vk_down)) { 

    y_speed = movement_speed 

}

x += x_speed 

y += y_speed


