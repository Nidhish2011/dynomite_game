t_min = 2
t_sec = 30

t_mil = 0

alarm[0] = 6 // fps

