// 1. Look for the specific dynamite object you are touching
var _target = instance_place(x, y, oDynomite);
var dynoCollection = []
// 2. If you are touching it, destroy it
if (_target != noone) {
    instance_destroy(_target);
    
    // 3. Optional: Add to a variable so you can track inventory
    // inventory += 1; 
}





with other{
	instance_destroy()
}